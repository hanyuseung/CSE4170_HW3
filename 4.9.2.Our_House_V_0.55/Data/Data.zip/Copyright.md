Copyright

1. static_objects
	- bus
	- cow
		"Cow" (https://skfb.ly/DTQH) by Josué Boisvert is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
		
	- dragon
	- bike 
		"Vincent JetPrince 1967 Dream bike" (https://skfb.ly/6BV6x) by Denis is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
	
	- godzilla
	- ironman
		"Iron Man Rig" (https://skfb.ly/6QSsy) by Darth Iron is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
		
	- optimus 
	- tank

2. dynamic_objects
	- ben
	- spider
		"Spider" (https://skfb.ly/5jih2f1dcb) by 3DHaupt is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
	
	- tiger
	- wolf